/* Partner 1 Name & E-mail: Emanuel Halfon ehalf001@ucr.edu
* Partner 2 Name & E-mail:  Christian Grayson cgray009@ucr.edu
* Lab Section: 024
* Assignment: Lab # 4 Exercise # 4
* Exercise Description: Adding the first bit and the second bit of an input.
*
* I acknowledge all content contained herein, excluding template or example
* code, is my own original work.
*/

#include <avr/io.h>


#define A0  (PINA & 0x01)
#define A1  ((PINA >> 1 ) & 0x01)
#define A2  ((PINA >> 2 ) & 0x01)

unsigned char SetBit(unsigned char x, unsigned char k, unsigned char b) {
	return (b ? x | (0x01 << k) : x & ~(0x01 << k));
}
unsigned char GetBit(unsigned char x, unsigned char k) {
	return ((x & (0x01 << k)) != 0);
}
enum  States {Start, Lock, trans_First, First, Unlock, trans_Second, Second} state;



int main(void)
{
	unsigned char Lock_Unlock = 0x00;
	PORTB = 0x00;
	state = Start;
	while(1)
	{

		switch(state) //Transitions
		{
			case Start:
			state = Lock;
			break;
			case Lock:
			if(A0 == 1 || A1 == 1 || A2 == 0)
			{
				state = Lock;
			}
			else
			{
				state = trans_First;
			}
			break;
			case trans_First:
			if((A0 == 1 || A1 == 1))
			{
				state = Lock;
			}
			else if(!A2)
			{
				state = First;
			}
			else
			{
				state = trans_First;
				break;
			}
			case First:
			if(A0 == 1 || A2 == 1)
			{
				state = Lock;
			}
			else if(A1)
			{
				state = Unlock;
			}
			else
			{
				state = First;
			}
			break;
			case Unlock:
			if(A0 == 1 || A1 == 1 || A2 == 0)
			{
				state = Unlock;
			}
			else
			{
				state = trans_Second;
			}
			break;
			case trans_Second:
			if((A0 == 1 || A1 == 1))
			{
				state = Unlock;
			}
			else if(!A2)
			{
				state = Second;
			}
			else
			{
				state = trans_Second;
				break;
			}
			case Second:
			if(A0 == 1 || A2 == 1)
			{
				state = Unlock;
			}
			else if(A1)
			{
				state = Lock;
			}
			else
			{
				state = Second;
			}
			break;
			default:
			if(Lock_Unlock == 0x00)
			{
				state = Lock;
			}
			else
			{
				state = Unlock;
			}
			
		}

		switch(state) //Actions
		{
			case Lock:
			PORTB = 0x00;
			Lock_Unlock = 0x00;
			break;
			case Unlock:
			PORTB = 0x01;
			Lock_Unlock = 0x01;
			break;
			default:
			PORTB = PORTB;
		}
	}
}