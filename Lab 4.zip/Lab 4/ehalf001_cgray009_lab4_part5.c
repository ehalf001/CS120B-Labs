/* Partner 1 Name & E-mail: Emanuel Halfon ehalf001@ucr.edu
* Partner 2 Name & E-mail:  Christian Grayson cgray009@ucr.edu
* Lab Section: 024
* Assignment: Lab # 4 Exercise # 5
* Exercise Description: Adding the first bit and the second bit of an input.
*
* I acknowledge all content contained herein, excluding template or example
* code, is my own original work.
*/

#include <avr/io.h>


#define A0  (PINA & 0x01)
#define A1  ((PINA >> 1 ) & 0x01)
#define A2  ((PINA >> 2 ) & 0x01)

unsigned char SetBit(unsigned char x, unsigned char k, unsigned char b) {
	return (b ? x | (0x01 << k) : x & ~(0x01 << k));
}
unsigned char GetBit(unsigned char x, unsigned char k) {
	return ((x & (0x01 << k)) != 0);
}
enum  States {Start, Lock, Current_A0, Current_A1, Current_A2, trans_Current, Unlock} state;



int main(void)
{
	unsigned char Lock_Unlock = 0x00;
	PORTB = 0x00;
	state = Start;
	unsigned char A[] = {'#', 'X', 'Y', 'X'};
	unsigned char i = 0;
	unsigned char curr = A[0];
	while(1)
	{

		switch(state) //Transitions
		{
			case Start:
				state = Lock;
				break;
			case Lock:
				if(curr == 'X')
				{
					state = Current_A0;
				}
				else if(curr == 'Y')
				{
					state = Current_A1;
				}
				else
				{
					state = Current_A2;
				}
				break;
			case Current_A0:
				if(A0 && !A1 && !A2)
				{
					state = trans_Current;
				}
				else if(!A0 && !A1 && !A2)
				{
					state = Current_A0;
				}
				else
				{
					if(Lock_Unlock)
					{
						state = Unlock;
					}
					else
					{
						state = Lock;
					}

				}
				break;
			case Current_A1:
				if(!A0 && A1 && !A2)
				{
					state = trans_Current;
				}
				else if(!A0 && !A1 && !A2)
				{
					state = Current_A1;
				}
				else
				{
					if(Lock_Unlock)
					{
						state = Unlock;
					}
					else
					{
						state = Lock;
					}

				}
				break;
			case Current_A2:
				if(!A0 && !A1 && A2)
				{
					state = trans_Current;
				}
				else if(!A0 && !A1 && !A2)
				{
					state = Current_A2;
				}
				else
				{
					if(Lock_Unlock)
					{
						state = Unlock;
					}
					else
					{
						state = Lock;
					}

				}
				break;
			case trans_Current:
				if(!(!A0 && !A1 && !A2))
				{
					state = trans_Current;
				}
				else if(i == sizeof(A))
				{
					if(Lock_Unlock)
					{
						state = Lock;
					}
					else
					{
						state = Unlock;
					}

				}
				else if(curr == 'X')
				{
					state = Current_A0;
				}
				else if(curr == 'Y')
				{
					state = Current_A1;
				}
				else
				{
					state = Current_A2;
				}
				break;
			case Unlock:
				if(curr == 'X')
				{
					state = Current_A0;
				}
				else if(curr == 'Y')
				{
					state = Current_A1;
				}
				else
				{
					state = Current_A2;
				}
				state = Unlock;
				break;
			default:
				if(Lock_Unlock)
				{
					state = Lock;
				}
				else
				{
					state = Unlock;
				}		
		}

		switch(state) //Actions
		{
			case Lock:
				i = 0x00;
				PORTB = 0x00;
				Lock_Unlock = 0x00;
				break;
			case trans_Current:
				i = i + 1;
				curr = A[i];
				break;
			case Unlock:
				i = 0x00;
				PORTB = 0x01;
				Lock_Unlock = 0x01;
				break;
			default:
				PORTB = PORTB;
		}
	}
}