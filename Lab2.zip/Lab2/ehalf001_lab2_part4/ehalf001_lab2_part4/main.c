/* Partner 1 Name & E-mail: Emanuel Halfon ehalf001@ucr.edu
* Partner 2 Name & E-mail:  Christian Grayson cgray009@ucr.edu
* Lab Section: 024
* Assignment: Lab # 2 Exercise # 4
* Exercise Description: Adding the first bit and the second bit of an input.
*
* I acknowledge all content contained herein, excluding template or example
* code, is my own original work.
*/

#include <avr/io.h>


int main(void)
{
    PINA  = 0x00;
	PINB  = 0x00;
	PINC  = 0x00;
	PORTD = 0x00;
    while (1) 
    {
		unsigned char PIN_A = PINA;
		unsigned char PIN_B = PINB;
		unsigned char PIN_C = PINC;
		unsigned short total_weight = PIN_A + PIN_B + PIN_C; // Take the total weight, have to use short because 
														  //if it is greater than 255, than it will be 0
		unsigned char  weight_diff  = PIN_C > PIN_A ? PIN_C - PIN_A : PIN_A - PIN_C; // Taking the absolute value of the 
																			    //difference using a ternary operator
		if(total_weight <= 140)
		{
			unsigned char temp = PIN_A + PIN_B + PIN_C;
			temp = temp >> 2; // Taking the six most significant bits
			PORTD = weight_diff > 80 ? (temp << 2) + 2 : temp << 2; // Put the six msb as an approximate of the weight
																    // If the weight diff is bigger than 80 then D1 is 1
		}
		else
		{
			PORTD = weight_diff > 80 ? 0xFF : 0xFD;	// Since the weight is greater than 140 then set the six msb to 1
													// If the weight diff is greater than 80 set D1 to 1
													// Since the total weight is greater than 140 then set D0 to 1
		}
    }
}

