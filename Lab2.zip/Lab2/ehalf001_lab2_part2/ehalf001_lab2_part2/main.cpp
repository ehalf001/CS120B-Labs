/* Partner 1 Name & E-mail: Emanuel Halfon ehalf001@ucr.edu
* Partner 2 Name & E-mail:  Christian Grayson cgray009@ucr.edu
* Lab Section: 024
* Assignment: Lab # 2 Exercise # 2
* Exercise Description: Adding the first bit and the second bit of an input.
*
* I acknowledge all content contained herein, excluding template or example
* code, is my own original work.
*/
#include <avr/io.h>


int main(void)
{
    PORTA = 0x00; // Configure port A's 4 pins as inputs
	PINA  = 0x00;
	PORTC = 0x00; // Configure port C as 0
	 // Records the total
    while (1) 
    {
		unsigned char Total = 0x00;
		unsigned char i;
		for(i = 0; i < 4; i++)
		{
			if(i == 0)
			{
				if((PINA & 0x01) == 0x01)
				{
					Total = Total + 1;
				}
			}
			else if(((PINA >> i) & 0x01) == 0x01)
			{
				Total = Total + 1;
			}
		}
		PORTC = Total;
    }
}

