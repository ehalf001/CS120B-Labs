/* Partner 1 Name & E-mail: Emanuel Halfon ehalf001@ucr.edu
* Partner 2 Name & E-mail:  Christian Grayson cgray009@ucr.edu
* Lab Section: 024
* Assignment: Lab # 2 Exercise # 1
* Exercise Description: Adding the first bit and the second bit of an input.
*
* I acknowledge all content contained herein, excluding template or example
* code, is my own original work.
*/

#include <avr/io.h>

int main(void)
{
	DDRA = 0x00; PORTA = 0xFF; // Configure port A's 8 pins as inputs
	DDRB = 0xFF; PORTB = 0x00; // Configure port B's 8 pins as outputs, initialize to 0s
	unsigned char tmpAZero = 0x00;
	unsigned char tmpAOne  = 0x00;
	while(1)
	{
		tmpAZero = PINA & 0x01; //Isolate First bit
		tmpAOne  = (PINA >> 1) & 0x01; //Isolate Second bit
		PORTB = (tmpAZero & ~tmpAOne); //PA0 and ~PA1
	}
	return 0;
}
