/* Partner 1 Name & E-mail: Emanuel Halfon ehalf001@ucr.edu
* Partner 2 Name & E-mail:  Christian Grayson cgray009@ucr.edu
* Lab Section: 024
* Assignment: Lab # 2 Exercise # 3
* Exercise Description: Adding the first bit and the second bit of an input.
*
* I acknowledge all content contained herein, excluding template or example
* code, is my own original work.
*/
#include <avr/io.h>


int main(void)
{
    PORTA = 0x00; // Configure port A's 4 pins as inputs
	PINA  = 0x00;
	PORTC = 0x00; // Configure port C as 0
	 // Records the total
    while (1) 
    {
		PORTC = PINA == 15 ? 0x8F : PINA;	//If all spaces are taken, than the value of PINA is 15, so P7 is 1 and P3-P0 is 1
    }										//If it is not, then it is just the same spaces taken up by PINA 
}

